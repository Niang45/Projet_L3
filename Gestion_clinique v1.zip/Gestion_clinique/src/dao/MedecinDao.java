/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;

/**
 *
 * @author Mr MOUHAMED NIANG
 */
import entities.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class MedecinDao implements IDao<Medecin>{
    private DataBase dataBase=new DataBase();
      private final String SQL_SELECT_MEDECIN_BY_ID =
            "SELECT * FROM user WHERE id =?";
    private final String SQL_INSERT="INSERT INTO `user`"
            + "(`nom`, `prenom`, `login`, `password`,role) "
            + "VALUES (?,?,?,?,?)";
   

    @Override
    public int insert(Medecin medecin) {
       int idMedecin=0;
        try {
            dataBase.openConnexion();
            dataBase.initPrepareStatement(SQL_INSERT);
            dataBase.getPs().setString(1, medecin.getNom());
            dataBase.getPs().setString(2, medecin.getPrenom());
            dataBase.getPs().setString(3, medecin.getLogin());
            dataBase.getPs().setString(4, medecin.getPassword());
            dataBase.getPs().setString(5, "ROLE_MEDECIN");
            dataBase.executeUpdate(SQL_INSERT);
            ResultSet rs =dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                idMedecin = rs.getInt(1);
            }
            } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
            dataBase.closeConnexion();   
        } 
        return idMedecin;
    }

    @Override
    public int update(Medecin ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Medecin> findAll(){
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Medecin findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
