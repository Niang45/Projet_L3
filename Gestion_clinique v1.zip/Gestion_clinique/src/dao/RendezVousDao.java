/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.*;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Time;
import java.sql.Date;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import view.ConnexionController;

public class RendezVousDao implements IDao<RendezVous>{
    //Requête sql
     private String SQL_SELECT="SELECT * FROM `rendezvous` ";
    private String SQL_INSERT="INSERT INTO `rendezvous`"
            + "`(`  `idPatient`, ` `libelle`, `type`)"
            + " VALUES (?,?,?)"
            ;
    private String SQL_UPDATE="UPDATE `rendezvous` SET `id`=?,"
            + "`date`=?,`time=?,libelle`=?,`type`=? WHERE id=?";
    private String SQL_BY_ID="SELECT * FROM `rendezvous` WHERE id=? ";
     private String SQL_BY_ALL="SELECT * FROM `rendezvous`";
         private final String SQL_CREATE_RV="SELECT * FROM rendezVous WHERE libelle=? AND date=? AND  heure=? AND type=? AND idPatient=? ";
     private DataBase dataBase=new DataBase();
     private Medecin medecin=new Medecin();
     private Patient patient=new Patient();
     private RendezVous rendezVous;
     
    @Override
    public int insert(RendezVous rendezVous) {
        int idRv=0;
        
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_INSERT);
         try {
             
             
              dataBase.getPs().setInt(1,ConnexionController.getCtrl().getUser().getId());
             dataBase.getPs().setDate(2, (Date) Date.from(Instant.now()));
              dataBase.getPs().setTime(3, (Time) Time.from(Instant.now()));
               dataBase.getPs().setString(4,rendezVous.getLibelle());
             dataBase.getPs().setString(5,rendezVous.getTypeDeService());
             dataBase.executeUpdate(SQL_INSERT);
             ResultSet rs = dataBase.getPs().getGeneratedKeys();
            if(rs.next())
            {
                idRv = rs.getInt(1);   
            }
         } catch (SQLException ex) {
             Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
         
        }finally{
            dataBase.closeConnexion();   
        } 
         return idRv;
        
       
    }
   
    @Override
    public int update(RendezVous ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RendezVous findById(int id) {
         throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
 public RendezVous CreatingRV (int idP,String libelle, java.sql.Date Date,java.sql.Time heure,String type){
      //RendezVous rendezVous = null;
        dataBase.openConnexion();
        dataBase.initPrepareStatement(SQL_CREATE_RV);
         try {
            
             dataBase.getPs().setInt(1, ConnexionController.getCtrl().getUser().getId());
            dataBase.getPs().setDate(2,  Date);
            dataBase.getPs().setTime(3, heure);
            dataBase.getPs().setString(4, libelle);
            dataBase.getPs().setString(5, type);
            ResultSet rs = dataBase.executeSelect(SQL_CREATE_RV);
        
            if(rs.next())
            {
                    rendezVous = new RendezVous(       
                   rs.getInt("idPatient"),
                    rs.getDate("date"),
                    rs.getTime("heure"),
                    rs.getString("libelle"),
                    rs.getString("type")
                     
                    
                            
                    );
            }

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rendezVous;
    }
 
 }
    
    
    
