/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;


import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.sql.Time;
import java.time.LocalDate;
import java.time.*;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


public interface Iservice {
    /*Se connecter */
    public User login(String login,String password);
    //Patient
    public  int addPatient(String nom,String prenom,String login,String password,String role,String antecedant);
   // public int findByIdPatient(int id);
    public boolean searchPatientById(int id);
    public int askRendezVous(int idP,String libelle, Date date,Time heure,String service);
    public List<RendezVous> showAllRendezVous();
   public RendezVous rv(int idP,String libelle, Date date,Time heure,String service);
    public List<RendezVous> showRendezVousByLibelle(String libelle);
     
    public List<Patient> findPatientById(int id);
    
    //Medecin
    public boolean searchDossierMedicalPatientById(int id);
    public List<RendezVous> showRendezVousByLibelleAndDateAndService(String libelle, LocalDate date,String heure,String service);
    public abstract int showDetailsConsultationById(int id);
    
    
    
    
    
    
    
    
    
    
    
      
    
    
}
