/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.PatientDao;
import dao.RendezVousDao;
import dao.UserDao;
import entities.DossierMedical;
import entities.Inscription;
import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import view.ConnexionController;



/**
 *
 * @author Mr Mouhamed Niang
 */
public class service implements Iservice {

    RendezVous rendezVous=new RendezVous();
    RendezVousDao daoRendezVous=new RendezVousDao(); 
    Patient patient =new Patient();
     UserDao daoUser=new UserDao();
     PatientDao daoPatient=new PatientDao();
    @Override
    public User login(String login,String password) {

       return daoUser.findUserLoginAndPassword(login, password);
    }
    
  
    

    @Override
    public boolean searchPatientById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    @Override
    public List<RendezVous> showAllRendezVous() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    @Override
    public boolean searchDossierMedicalPatientById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    @Override
    public int showDetailsConsultationById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int addPatient(String nom,String prenom ,String login ,String password,String role,String antecedant) {
        
         return daoPatient.insert(patient);
        
    }
    @Override
    public List<RendezVous> showRendezVousByLibelle(String libelle) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public List<RendezVous> showRendezVousByLibelleAndDateAndService(String libelle, LocalDate date, String heure, String service) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   /* public RendezVous CreateRV(int idP,String libelle, Date date, Time heure, String service) {
        return daoRendezVous.CreatingRV(idP,libelle, date, heure, service);
    }*/


    @Override
    public RendezVous rv(int idP,String libelle, java.util.Date date, Time heure, String service) {
        return daoRendezVous.CreatingRV(idP, libelle, (Date) date, heure, service);
    }

    @Override
    public int askRendezVous(int idP, String libelle, java.util.Date date, Time heure, String service) {
     
       return daoRendezVous.insert(rendezVous);
    }
      
    private List<Patient> patients=Arrays.asList(
            new Patient()
    );
    /*@Override
    public List<Patient> findPatientById(int id) {
        
        
         return (List<Patient>) patients.stream()
                 .filter((Patient patient)->patient.getId())
                 .findFirst().get();
    }

   /* public int findByIdPatient(int id) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    return 0;
    }*/

    @Override
    public List<Patient> findPatientById(int id) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            
         return null;
    }

   
    
    

  


   

    

     

   

   
   
   

    
    
}
