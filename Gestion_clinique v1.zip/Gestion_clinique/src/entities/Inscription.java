/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;
import entities.Patient;

/**
 *
 * @author MOUHAMED NIANG
 */
public class Inscription {
    private int id;
    private String nom;
    private String prenom;
    private String login;
    private String password;
    
    private Patient patient;


    public Inscription() {
    }

    public Inscription(int id, String nom, String prenom, String login, String password, Patient patient) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.login = login;
        this.password = password;
        this.patient = patient;
    }

    public Inscription(String nom, String prenom, String login, String password) {
        this.nom = nom;
        this.prenom = prenom;
        this.login = login;
        this.password = password;
      
    }

    public Inscription(Patient patient) {
        
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public Patient getPatient() {
        return patient;
    }

  
    

  

   
    
    
}
