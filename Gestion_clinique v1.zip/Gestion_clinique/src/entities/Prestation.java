/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;


public class Prestation extends RendezVous{

    private int codeprestation;
    private String libelle;
    
    //attribut navigationnel
    private  ResponsablePrestation responsablePrestation; 
    
    public Prestation() {
    }

    public Prestation(int codeprestation, int id, LocalDate date, String libelle, String type, LocalTime time) {
        super(id, date, libelle, type, time);
        this.codeprestation = codeprestation;
    }

    




    public int getCodeprestation() {
        return codeprestation;
    }

    public void setCodeprestation(int codeprestation) {
        this.codeprestation = codeprestation;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
    
    
}
