/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import view.ConnexionController;


public class RendezVous {
    private int id;
    protected LocalDate date;
    protected String libelle;
    protected String type;
    protected LocalTime time;
    //attribut navigationnel
    private Secretaire secretaire;
    private Patient patient;
   private int idPatient;
    public RendezVous() {
    }

    public RendezVous(int id) {
        this.id = id;
    }

    public RendezVous(int aInt, Date date, Time time, String string, String string0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    //update
    public RendezVous(int id, LocalDate date, String libelle, String type, LocalTime time) {
        this.id = id;
        this.date = date;
        this.libelle = libelle;
        this.type= type;
        this.time = time;
    }
    //update
    //insert
    public RendezVous(LocalDate date, String libelle, String typeDeService, LocalTime time) {
        this.date = date;
        this.libelle = libelle;
        this.type = type;
        this.time = time;
    }
     

    public RendezVous(int id, LocalDate date, String libelle, String typeDeService, LocalTime time, int idPatient) {
        this.id = id;
        this.date = date;
        this.libelle = libelle;
        this.type = type;
        this.time = time;
        this.idPatient = idPatient;
    }

    /*public RendezVous(String chosenLib, Date sqlDate, Time heure, String chosenPrestation) {
        
    }*/

    public RendezVous(String libelle, LocalDate date, LocalTime time, String type) {
      this.date = date;
        this.libelle = libelle;
        this.type = type;
        this.time = time;
    }
    
    

    public void setTypeDeService(String typeDeService) {
        this.type = type;
    }

    public String getTypeDeService() {
        return type;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getTime() {
        return time;
    }

   

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

   

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
      
}
