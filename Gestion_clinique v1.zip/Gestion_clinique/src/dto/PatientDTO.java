/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author MOUHAMED NIANG
 */
import entities.Patient;
public class PatientDTO {
    private int id;
    private String nom;
    private String prenom;
    private String login;
    private String password;
    private String antecedantMedical;
    private final String ROLE="ROLE_PATIENT";

    public PatientDTO() {
    }

    public void toDTO(Patient patient) {
        this.id = patient.getId();
        this.nom = patient.getNom();
        this.prenom = patient.getPrenom();
        this.login = patient.getLogin();
        this.password = patient.getPassword();
        this.antecedantMedical = patient.getAntecedantMedical();
    }
    
    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public String getAntecedantMedical() {
        return antecedantMedical;
    }

    public String getROLE() {
        return ROLE;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAntecedantMedical(String antecedantMedical) {
        this.antecedantMedical = antecedantMedical;
    }
    
    
}
