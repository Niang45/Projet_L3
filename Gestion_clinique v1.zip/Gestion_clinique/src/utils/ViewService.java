/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import javafx.scene.control.ComboBox;

/**
 *
 * @author MOUHAMED NIANG
 */
public class ViewService {
    public static void  loadComboBoxConsultation(ComboBox<String>typeService) {
        typeService.getItems().add("Dentiste");
        typeService.getItems().add("ophtalmologie");
        typeService.getItems().add("Medecin général");
        typeService.getItems().add("Cardiologie");
        typeService.getSelectionModel().selectFirst();
    }
    public static void loadComboBoxPrestation(ComboBox<String>typePrestation){
        typePrestation.getItems().add("Radiologie");
        typePrestation.getItems().add("Analyse");
        typePrestation.getSelectionModel().getSelectedItem();
    }
    public static void loadComboBoxLibelle(ComboBox<String>typeRv){
        typeRv.getItems().add("Consultation");
         typeRv.getItems().add("Prestation");
    }
}
