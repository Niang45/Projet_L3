/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;
import dao.PatientDao;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import services.service;
import entities.User;
import javafx.scene.Parent;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.animation.*;
import javafx.scene.paint.Color;

/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
public class ConnexionController implements Initializable {

    @FXML
    private TextField txtLogin;
    @FXML
    private TextField txtPassword;
    @FXML
    private Text txtError;
    @FXML
    private Button btnSignup;
  private final service service = new service();
    
    private static ConnexionController ctrl;
    private static IncriptionController ictrl;
    private User user;
    @FXML
    private Label warning;
    @FXML
    private AnchorPane paneField;
    @FXML
    private Pane paneSide;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtError.setVisible(false);
        warning.setVisible(false);
         ctrl = this;
    }    
    private PatientDao daoPatient;
    @FXML
    private void handleClear(ActionEvent event) {
        txtLogin.clear();
        txtPassword.clear();
        txtError.setVisible(false);
        warning.setVisible(false);
    }

    @FXML
    private void handleConnection(ActionEvent event)  {
         String login = txtLogin.getText().trim();
        String password = txtPassword.getText().trim();
        if(login.isEmpty() || password.isEmpty())
        {
            //si l'un des champs on affiche le message suivant
          txtError.setText("Login et le mot de passe obligatoire !!!");
          //on active la visibilité du message  d'erreur
          txtError.setVisible(true);
          warning.setVisible(true);
        }
        else{
            user=service.login(login, password);
           
           if(user == null)
            {
              //affecter txtError le message suivant
               txtError.setText("Login ou le mot de passe incorrect!!!");
               //on active la visibilité du message  d'erreur
               txtError.setVisible(true);
               warning.setVisible(true);
           }
           else
            {
              //Cache la fénétre de connexion
             this.txtError.getScene().getWindow().hide();
             this.warning.getScene().getWindow().hide();
              AnchorPane root = null;
              
              try {
                  //on charge la page d'accueil
                  root = FXMLLoader.load(getClass().getResource("/view/V_patient.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
                  stage.show();
                } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
     public static ConnexionController getCtrl() {
        return ctrl;
    }

    public User getUser() {
        return user;
    }

    @FXML
    private void handleCreate(ActionEvent event) throws IOException {
        Stage stage=(Stage) btnSignup.getScene().getWindow();
        stage.close();
        Stage primaryStage=new Stage();
        Parent  root=FXMLLoader.load(getClass().getResource("/view/v_inscription.fxml"));
        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("Clinique 221");       
        primaryStage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
         primaryStage.show();             
    }

   
  
  

    
}
