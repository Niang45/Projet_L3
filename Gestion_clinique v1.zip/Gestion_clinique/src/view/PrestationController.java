/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;


import com.jfoenix.controls.JFXTextField;


//import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import dao.PatientDao;
import dao.RendezVousDao;
//import java.sql.Date;
import entities.Medecin;
import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
//import java.time.ZoneId;
//import java.time.format.DateTimeFormatter;
//import java.util.Date;
import java.util.ResourceBundle;
//import javafx.beans.Observable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SingleSelectionModel;
import services.service;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
import utils.ViewService;

public class PrestationController implements Initializable {
    //Date date=new Date();
    private JFXTextField txtPrestation;
   
    @FXML
    private ComboBox<String> typePrestation;
    @FXML
    private Button btnValider;
    private String typeDeService;
    private String libelle;
    private static PrestationController prctrl;
    @FXML
    private Text txtErrorLib;
    @FXML
    private GridPane txtErrorDate;
    private Text txtErrorHour;
    @FXML
    private Text txtErrorPrestation;
    private Text txtErrorJour;
    @FXML
    private JFXTextField typeRv;
  // RendezVous rendezVous=new RendezVous();
   private PatientDao daoPatient;
   private final service service = new service();
   private Medecin medecin;
   private RendezVous rendezVous;
   private User user;
  private Patient patient;
   private RendezVousDao daoRendezVous;
   
    /**
     * Initializes the controller class.
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ViewService.loadComboBoxPrestation(typePrestation);
        libelle=typeRv.getText().trim();
        prctrl=this;
        txtErrorLib.setVisible(false);
        txtErrorPrestation.setVisible(false);
       
       // anneeEnCours = cboAnnee.getSelectionModel().getSelectedItem();
    // Time  heure=Time.valueOf(LocalTime.now());
     Time time=  Time.valueOf(LocalTime.MIN);
     LocalDate Date=LocalDate.now();
    }    

    public static PrestationController getPrctrl() {
        return prctrl;
    }  
    
  
    @FXML
    private void handleSignUp(ActionEvent event) throws IOException{

        if(libelle.isEmpty()){
                txtErrorLib.setVisible(true);
                txtErrorLib.setText("Libellé est obligatoire !!!");
        }
       if(!libelle.equals("Prestation")){
                txtErrorLib.setVisible(true);
                txtErrorLib.setText("Ce rendez-vous n'est disponible que pour une prestation !!!");
        }
        if(typePrestation.getSelectionModel().isEmpty()){
            txtErrorPrestation.setVisible(true);
            txtErrorPrestation.setText("Prestation est obligatoire !!!");
        }else{
          

         
          int  id=ConnexionController.getCtrl().getUser().getId();
        rendezVous=service.rv(id,libelle,Date.valueOf(LocalDate.MIN),Time.valueOf(LocalTime.MIN)  , typeDeService);
        /* int idRv=service.askRendezVous(id, libelle, date, time, typeDeService);
         if(rendezVous==null){
             Alert alert=new Alert(AlertType.INFORMATION);
             alert.setContentText("erreur");
             alert.show();
         }else{
             Alert alert=new Alert(AlertType.INFORMATION);
             alert.setContentText("succes");
             alert.show();
         }*/
        Alert alert=new Alert(AlertType.INFORMATION);
             alert.setContentText(typeDeService);
             alert.show();
        }
    }
public RendezVous getRendezVous() {
        return rendezVous;
    }
public User getUser(){
    return user;
}
    private String choix;
    @FXML
    private void handleChangerPrestation(ActionEvent event) {
        /*Recuperation d'une valeur via la view*/
       choix=typePrestation.getSelectionModel().getSelectedItem();
        
    }
   
   

   
}
 

    
      
   

