/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import dao.DataBase;
import dao.PatientDao;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import utils.ViewService;

/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
public class PatientController implements Initializable {

    private static PatientController pctrl;
     private static PrestationController prctrl;
    DataBase dataBase=new DataBase();
    @FXML
    private Button btnSignOut;
    @FXML
    private AnchorPane anchorContent;
    @FXML
    private Button btnConsultation;
    @FXML
    private Button btnPrestation;
    @FXML
    private Button btnShow;
    @FXML
    private Text txtProfil;
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    public void loadView(String view) throws IOException{
        AnchorPane root;
        //on charge la vue
        root=FXMLLoader.load(getClass().getResource("/view/"+view+".fxml"));
        anchorContent.getChildren().clear();
        anchorContent.getChildren().add(root);
    }
    private PatientDao daoPatient;
    @Override
    public void initialize(URL url, ResourceBundle rb)  {
        try {
            loadView("v_consult");
       txtProfil.setText(ConnexionController.getCtrl().getUser().getNom().toUpperCase());
    //   txtProfil.setText(daoPatient.findById(id));
       pctrl=this;
        } catch (IOException ex) {
            Logger.getLogger(PatientController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    

    @FXML
    private void handleSignOut(ActionEvent event) {  
        try {
                dataBase.closeConnexion();
                 AnchorPane root = null;
                  Stage stage=(Stage) btnSignOut.getScene().getWindow();
                  //on charge la page d'accueil
                  root = FXMLLoader.load(getClass().getResource("/view/v_connexion.fxml"));
                  Alert alert=new Alert (Alert.AlertType.INFORMATION);
                  //on initalise l'entête du message d'alert
                  alert.setHeaderText("Déconnexion");
                  //on intialise le contenu du message d'alert
                  alert.setContentText("Déconnexion effectuée avec succés");
                  Scene scene = new Scene(root);
                  //on affiche le message alert
                  alert.showAndWait();
                  //ajouter un titre  a la fenetre
                  stage.setTitle("Clinique 221");
                     //ajouter icon a la fenetre
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }

    @FXML
    private void handleConsultation(ActionEvent event) throws IOException {
        loadView("v_consult");
        
    }

    @FXML
    private void handlePrestation(ActionEvent event)  {
        try {
            loadView("v_prestation");
        } catch (IOException ex) {
            Logger.getLogger(PatientController.class.getName()).log(Level.SEVERE, null, ex);
        }
        PrestationController.getPrctrl();
    }



    
}
