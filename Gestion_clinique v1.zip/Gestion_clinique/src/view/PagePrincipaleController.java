/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
public class PagePrincipaleController implements Initializable {

    @FXML
    private Button btnSign;
    @FXML
    private Button btnLogn;
    @FXML
    private Button btnAskC;
    @FXML
    private Button btnAskP;
 

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

/*
    @FXML
    private void handleLogin(ActionEvent event) throws IOException {
            this.btnLogn.getScene().getWindow().hide();
             this.btnAskC.getScene().getWindow().hide();
             this.btnAskP.getScene().getWindow().hide();
         AnchorPane root = null;
         root = FXMLLoader.load(getClass().getResource("/view/Authentification.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
                  stage.show();
    }

   
    


    */

    @FXML
    private void handleSignUp(ActionEvent event) throws IOException {
         AnchorPane root = null;
         this.btnSign.getScene().getWindow().hide();
         root = FXMLLoader.load(getClass().getResource("/view/v_inscription.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
                  stage.show();
    }

    @FXML
    private void handleConnection(ActionEvent event) throws IOException {
          this.btnLogn.getScene().getWindow().hide();
             this.btnAskC.getScene().getWindow().hide();
             this.btnAskP.getScene().getWindow().hide();
         AnchorPane root = null;
         root = FXMLLoader.load(getClass().getResource("/view/v_authentification.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
                  stage.show();
    }
}
