/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTimePicker;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.text.Text;
import utils.ViewService;

/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
public class V_consultController implements Initializable {

    @FXML
    private JFXTextField txtConsult;
    @FXML
    private JFXTimePicker txtHour;
    @FXML
    private ComboBox<String> typeService;
    @FXML
    private Button btnValider;
     private String chosenService;
    @FXML
    private JFXDatePicker txtDate;
    private V_consultController vctrl;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtHour._24HourViewProperty();
       ViewService.loadComboBoxConsultation(typeService);
       //on recupère l'element selectiondItem();
       chosenService=typeService.getSelectionModel().getSelectedItem();
       vctrl=this;
    }    

    @FXML
    private void handleSave(ActionEvent event) {
    }
    
}
