/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import entities.Patient;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import dao.PatientDao;
import static java.sql.Types.NULL;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import services.service;
import javafx.scene.text.Text;
/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
public class IncriptionController implements Initializable {

   
    @FXML
    private TextField txtNom;
    @FXML
    private TextField txtPassword;
    @FXML
    private TextField txtPrenom;
    @FXML
    private TextField txtLogin;
    @FXML
    private Text txtError;
    @FXML
    private FontAwesomeIcon txtWarning;
    private int idPatient;
    private final String ROLE="ROLE_PATIENT";
    service  service=new service();
  //  ObservableList<String> patient = FXCollections.observableArrayList();
    @FXML
    private Button btnSignup;
   public static IncriptionController  Ctrl;
    private Patient patient ; 
    @FXML
    private TextArea txtAntecedants;
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        txtWarning.setVisible(false);
        txtError.setVisible(false);
        Ctrl=this;
        
    }    


     
    public void clearField(){
    txtNom.clear();
    txtPrenom.clear();
    txtLogin.clear();
    txtPassword.clear();
    }
    
    @FXML
    private void handleReset(ActionEvent event) {
          clearField();
         this.txtError.setVisible(false);
         this.txtWarning.setVisible(false);
        
    }

   

    @FXML
    private void handleSignUp(ActionEvent event) {
         String nom=txtNom.getText().trim();
        String prenom=txtPrenom.getText().trim();
        String login=txtLogin.getText().trim();
        String password=txtPassword.getText().trim();
        String antecedant=txtAntecedants.getText().trim();
        txtError.setVisible(false);
        if(nom.isEmpty()||prenom.isEmpty()||login.isEmpty()||password.isEmpty()){
            txtError.setText("Veuillez remplir les champs vides!!!");
            txtError.setVisible(true);
      //      txtWarning.setVisible(true);
        }
      
        else{
            
         if(antecedant.isEmpty()){
             
             antecedant=null;
         }
          Patient patient=new Patient(nom,prenom,login,password,ROLE,antecedant);
             PatientDao daoPatient=new PatientDao();
         service.addPatient(nom,prenom,login,password,ROLE,antecedant);
        int code =daoPatient.insert(patient);
          
            this.txtError.getScene().getWindow().hide();
          //   this.txtWarning.getScene().getWindow().hide();
            AnchorPane root = null;
              //          int id_patient = service.addPatient(patient);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        // Add custom Image to Dialog's title bar
        final Image APPLICATION_ICON = new Image("/images/icons8_XING_100px.png");
      
            alert.setTitle("Inscription");
            alert.setHeaderText("Inscription réussie ");//affichage àl'entête du message
            alert.setContentText("Soyez le bienvenue cher(e) patient(e)"+txtNom.getText()+"\t"+txtPrenom.getText());//contenu du mesage d'alert
            alert.showAndWait();
              try {
                  
                  //on charge la page d'accueil
                  root = FXMLLoader.load(getClass().getResource("/view/v_connexion.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);

                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
          }
    }

    @FXML
    private void handleConnect(ActionEvent event) {
        
        try {
                 AnchorPane root = null;
                  Stage stage=(Stage) btnSignup.getScene().getWindow();
                  //on charge la page d'accueil
                  root = FXMLLoader.load(getClass().getResource("/view/v_connexion.fxml"));
                  Scene scene = new Scene(root);
                  //ajouter un titre 
                  stage.setTitle("Clinique 221");
                     //ajouter icon
                  stage.getIcons().add(new Image("/images/icons8_XING_100px.png"));
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    
   }
    public static IncriptionController getCtrl() {
        return Ctrl;
    }
    public User getDaoPatient() {
        return patient;
    }

    
}
