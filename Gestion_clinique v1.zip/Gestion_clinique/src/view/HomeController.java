/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author MOUHAMED NIANG
 */
public class HomeController implements Initializable {

    @FXML
    private Text txtProfil;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleLoadConsultation(ActionEvent event) {
    }

    @FXML
    private void handleLoadPrestation(ActionEvent event) {
    }

    @FXML
    private void handleLoadShowRv(ActionEvent event) {
    }

    @FXML
    private void handleSignOut(ActionEvent event) {
    }
    
}
